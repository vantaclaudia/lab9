package com.company;

import java.util.LinkedList;
import java.util.Scanner;

class Ex4 {
    public static void verify(LinkedList<String> L, LinkedList<String> P) {
        int counter = 0;
        String sen = null;
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduceti prima propozitie: ");
        sen = sc.nextLine();
        L.add(sen);
        String sentence = L.toString();
        String[] words = sentence.split("[\\s+]");
        for (int i = 0; i < words.length; i++) {
            words[i] = words[i].replaceAll("[^\\w]", "");

        }
        L.clear();
        for (String s : words)
            if (!s.equals(""))
                L.add(s);
        System.out.println("Introduceti a doua propozitie: ");
        sen = sc.nextLine();
        P.add(sen);
        String sentences = P.toString();
        String[] words1 = sentences.split("[\\s+]");
        for (int i = 0; i < words1.length; i++) {
            words1[i] = words1[i].replaceAll("[^\\w]", "");

        }
        P.clear();
        for (String s : words1)
            if (!s.equals(""))
                P.add(s);
        for (int i = 0; i < L.size(); i++) {
            for (int j = 0; j < P.size(); j++) {
                if (P.get(j).equals(L.get(i))) {
                    counter++;
                }
            }
        }
        System.out.println("Propozitiile au in comun " + (counter) + " cuvinte.");

    }

    public static void main(String[] args) {
        LinkedList<String> L = new LinkedList<>();
        LinkedList<String> P = new LinkedList<>();
        verify(L, P);
    }
}
