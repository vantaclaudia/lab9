package com.company;

import java.util.Scanner;

class Ex6 {

    static void getJosephusPosition(int m, int n) {
        Node head = new Node(1);
        Node prev = head;
        for (int i = 2; i <= n; i++) {
            prev.next = new Node(i);
            prev = prev.next;
        }

        prev.next = head;

        Node ptr1 = head, ptr2 = head;

        while (ptr1.next != ptr1) {

            int count = 1;
            while (count != m) {
                ptr2 = ptr1;
                ptr1 = ptr1.next;
                count++;
            }

            ptr2.next = ptr1.next;
            ptr1 = ptr2.next;
        }
        System.out.println("Ultima persoana se afla pe pozitia a " + ptr1.data + "-a. ");
    }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Numarul de participanti este de: ");
        int n = sc.nextInt();
        System.out.println("Pasul: ");
        int m = sc.nextInt();
        getJosephusPosition(m, n);
    }

    static class Node {
        public int data;
        public Node next;

        public Node(int data) {
            this.data = data;
        }
    }
}