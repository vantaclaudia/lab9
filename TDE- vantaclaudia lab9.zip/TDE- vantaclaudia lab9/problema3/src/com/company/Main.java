package com.company;

import java.util.LinkedList;
import java.util.Scanner;

class Ex3 {
    public static void sterge(LinkedList<String> L, LinkedList<Integer> P, String word){
        L.add("audi");
        L.add("bmw");
        L.add("mercedes");

        System.out.println("Elementele listei sunt:");
        for(int i = 0;i< L.size();i++)
        {P.add(L.indexOf(L.get(i)));
            System.out.println(L.get(i));
            System.out.println(P.get(i));}
        int ind = P.size();
        Scanner sc = new Scanner(System.in);
        System.out.println("Alegeti un numar mai mic decat " + ind + ": ");
        int ch = sc.nextInt();
        if(ch-1>=P.size()){
            System.out.println("Numarul e invalid! ");
        }
        else
        {
            L.remove(ch-1);
            System.out.println("Cuvant eliminat! ");
            for(int i = 0;i< L.size();i++)
                System.out.println(L.get(i));
        }
    }


    public static void main(String[] args) {
        String word = "";
        LinkedList<String> L = new LinkedList<>();
        LinkedList<Integer> P = new LinkedList<>();
        sterge(L,P,word);
    }
}
