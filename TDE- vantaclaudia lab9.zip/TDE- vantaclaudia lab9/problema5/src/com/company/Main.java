package com.company;

import java.util.*;

class Ex5 {
    public static void cut(LinkedList<String> L, LinkedList<String> P) {
        int intro;
        int outro;
        String word = "";
        String words = "";
        String sen = null;
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduceti prima propozitie: ");
        sen = sc.nextLine();
        L.add(sen);
        System.out.println("Caracterul de inceput ales este: ");
        intro = sc.nextInt();
        System.out.println("Caracterul de sfarsit ales este: ");
        outro = sc.nextInt();
        String sentence = L.toString();

        char[] letters = sentence.toCharArray();
        List<char[]> asList = Arrays.asList(letters);

        List<Character> listC = new ArrayList<Character>();
        for (char c : letters) {
            listC.add(c);
        }
        for (int i = 1; i < letters.length - 1; i++) {
            if (i >= intro && i < outro) {
                word = word + letters[i];
            } else {
                words = words + letters[i];
            }


        }

        L.clear();
        L.add(words);
        P.add(word);
        System.out.println(L);
        System.out.println(P);


    }

    public static void main(String[] args) {
        LinkedList<String> L = new LinkedList<>();
        LinkedList<String> P = new LinkedList<>();
        cut(L, P);
    }
}
