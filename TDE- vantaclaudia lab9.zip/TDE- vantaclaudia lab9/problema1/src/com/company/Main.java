package com.company;

import java.util.LinkedList;
import java.util.Scanner;

class Ex1 {
    public static void Func( LinkedList<String> LLL,String word){

        System.out.println("Introduceti niste valori. \nUltimul caracter trebuie sa fie: STOP. ");
        Scanner sc = new Scanner(System.in);
        word = sc.nextLine();
        LLL.add(word);
        while(!word.equals("STOP")){
            word = sc.nextLine();
            LLL.add(word);

        }
            LLL.removeLast();
        System.out.println("Elementele listei sunt:");
        for(int i = 0;i< LLL.size();i++)
        System.out.println(LLL.get(i));}


    public static void main(String[] args) {
        LinkedList<String> LLL  = new LinkedList<String>();
        String word = null;
	Func(LLL,word);
    }
}
