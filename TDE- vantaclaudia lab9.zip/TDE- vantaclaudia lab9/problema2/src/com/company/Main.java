package com.company;

import java.util.LinkedList;
import java.util.Scanner;

class Ex2 {
    public static void Func( LinkedList<String> LLL, String[] SSS,String word) {

        System.out.println("Introduceti valorile dorite. \nUltimul caracter trebuie sa fie: STOP. ");
        Scanner sc = new Scanner(System.in);
        word = sc.nextLine();
        LLL.add(word);
        while (!word.equals("STOP")) {
            word = sc.nextLine();
            LLL.add(word);

        }
        LLL.removeLast();

        for (int i = 0; i < LLL.size(); i++)
            SSS[i] = LLL.get(i);
    }


    public static void main(String[] args) {
        String[] SSS = new String[100];
        QuickT Table = new QuickT();
        LinkedList<String> LLL  = new LinkedList<String>();
        String word = null;
        Func(LLL,SSS,word);
        int n = LLL.size();
        QuickT.quick(SSS,0,n-1);
        LLL.clear();
        for (int i = 0; i < n; i++){
            LLL.add(SSS[i]);
        }
        System.out.println(LLL);
    }
}